#!/bin/bash
# Hardware Backend Installation Script

set -e

echo "🚀 Installing Hardware Backend System"
echo "======================================"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "❌ This script must be run as root (use sudo)"
   exit 1
fi

# Create system user
if ! id "hardware" &>/dev/null; then
    echo "👤 Creating system user: hardware"
    useradd -r -s /bin/false -d /opt/hardware-backend hardware
fi

# Create directories
echo "📁 Creating directories..."
mkdir -p /opt/hardware-backend
mkdir -p /var/log/hardware-backend
mkdir -p /var/lib/hardware-backend
mkdir -p /etc/hardware-backend

# Copy files
echo "📋 Copying files..."
cp -r src/ /opt/hardware-backend/
cp -r config/ /etc/hardware-backend/ 2>/dev/null || true
cp *.py /opt/hardware-backend/
cp CMakeLists.txt /opt/hardware-backend/

# Set permissions
echo "🔐 Setting permissions..."
chown -R hardware:hardware /opt/hardware-backend
chown -R hardware:hardware /var/log/hardware-backend
chown -R hardware:hardware /var/lib/hardware-backend
chmod 755 /opt/hardware-backend
chmod 755 /var/log/hardware-backend
chmod 755 /var/lib/hardware-backend

# Build C++ backend
echo "🔨 Building C++ backend..."
cd /opt/hardware-backend
mkdir -p build
cd build
cmake ..
make

# Install Python dependencies
echo "🐍 Installing Python dependencies..."
pip3 install -r /opt/hardware-backend/requirements.txt

# Install service
echo "⚙️  Installing system service..."
cp /tmp/hardware-backend.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable hardware-backend

echo "✅ Installation completed successfully!"
echo ""
echo "Next steps:"
echo "1. Configure the system: /etc/hardware-backend"
echo "2. Start the service: systemctl start hardware-backend"
echo "3. Check status: systemctl status hardware-backend"
